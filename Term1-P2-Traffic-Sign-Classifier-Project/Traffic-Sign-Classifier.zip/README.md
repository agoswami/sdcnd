## Project: Traffic Sign Recognition Program
[![Udacity - Self-Driving Car NanoDegree](https://s3.amazonaws.com/udacity-sdc/github/shield-carnd.svg)](http://www.udacity.com/drive)

Overview
---
In this project, you will use what you've learned about deep neural networks and convolutional neural networks to classify traffic signs. You will train and validate a model so it can classify traffic sign images using the [German Traffic Sign Dataset](http://benchmark.ini.rub.de/?section=gtsrb&subsection=dataset). After the model is trained, you will then try out your model on images of German traffic signs that you find on the web.

We have included an Ipython notebook that contains further instructions 
and starter code. Be sure to download the [Ipython notebook](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/Traffic_Sign_Classifier.ipynb). 

We also want you to create a detailed writeup of the project. Check out the [writeup template](https://github.com/udacity/CarND-Traffic-Sign-Classifier-Project/blob/master/writeup_template.md) for this project and use it as a starting point for creating your own writeup. The writeup can be either a markdown file or a pdf document.

To meet specifications, the project will require submitting three files: 
* the Ipython notebook with the code
* the code exported as an html file
* a writeup report either as a markdown or pdf file 

Creating a Great Writeup
---
A great writeup should include the [rubric points](https://review.udacity.com/#!/rubrics/481/view) as well as your description of how you addressed each point.  You should include a detailed description of the code used in each step (with line-number references and code snippets where necessary), and links to other supporting documents or external references.  You should include images in your writeup to demonstrate how your code works with examples.  

All that said, please be concise!  We're not looking for you to write a book here, just a brief description of how you passed each rubric point, and references to the relevant code :). 

You're not required to use markdown for your writeup.  If you use another method please just submit a pdf of your writeup.

The Project
---
The goals / steps of this project are the following:
* Load the data set
* Explore, summarize and visualize the data set
* Design, train and test a model architecture
* Use the model to make predictions on new images
* Analyze the softmax probabilities of the new images
* Summarize the results with a written report

### Dependencies
This lab requires:

* [CarND Term1 Starter Kit](https://github.com/udacity/CarND-Term1-Starter-Kit)

The lab environment can be created with CarND Term1 Starter Kit. Click [here](https://github.com/udacity/CarND-Term1-Starter-Kit/blob/master/README.md) for the details.

### Data Set Summary & Exploration

#### 1. Provide a basic summary of the data set. In the code, the analysis should be done using python, numpy and/or pandas methods rather than hardcoding results manually.

I used the pandas library to calculate summary statistics of the traffic
signs data set:

* The size of training set is 34799
* The size of the validation set is 4410
* The size of test set is 12630
* The shape of a traffic sign image is (32, 32, 3)
* The number of unique classes/labels in the data set is 43

#### 2. Exploratory visualization of the dataset.

Here is an exploratory visualization of the data set. It is a bar chart showing how the data is distributed among classes

Below is visualization on Training Data Set

![Test Image1](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/data_set_images/train_data_set.jpg)

Below is visualization on Validation Data Set

![Test Image2](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/data_set_images/valid_data_set.png)

Below is visualization on Test Data Set

![Test Image3](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/data_set_images/test_data_set.png)

### Design and Test a Model Architecture

#### 1. Technique used for preprocessing - NORMALIZATION

As, the first step with the data set. I performed pre-processing using normalization technique pixel = (pixel -128)/128. Below are two images one before pre-processing and another one after normalization.

REGULAR IMAGE 

![Test Image4](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/normalized_images/speed-30_reg.png)

NORMALIZED

![Test Image5](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/normalized_images/speed-30_nor.png)

We did not do go for greyscaling, although we could have also gone for it. Next, time with more time in hand will try that.


#### 2. Following is the final model architecture in the tabular format ( including model type, layers, layer sizes, connectivity, etc.) 

My final model consisted of the following layers:

| Layer         		|     Description	        					| 
|:---------------------:|:---------------------------------------------:| 
| Input         		| 32x32x3 RGB image   							| 
| Layer 1: Convolution 3x3     	| Convolutional. Filter - 5,5,3,6 Input = 32x32x3. Output = 28x28x6. 	|
| Activation:| RELU					|
| Max Pooling: | Stride:2x2 Input = 28x28x6. Output = 14x14x6.|
| Layer 2: Convolutional| Output = 10x10x16|
| Activation:|  RELU|
| Max Pooling: | Input = 10x10x16. Output = 5x5x16|
| Flatten:| Input = 5x5x16. Output = 400|
| Layer 3: Fully Connected.| Input = 400. Output = 120|
| Activation:| RELU|
| Layer 4: Fully Connected| Input = 120. Output = 84|
| Activation:| RELU|
| Applying dropouts | keep_prob = 0.68 |
| Layer 5: Fully Connected | Input = 84. Output = 10|

#### 3. Following is the training approach used including ( the type of optimizer, the batch size, number of epochs and any hyperparameters such as learning rate)

To train the model, I have used adam optimizer. The BATCH is 65 and number of EPOCHS is 100. I have used learning rate as 0.0088. To initialize weight variable I have used mean = 0, stddev = 0.1

#### 4. Following section describes the model results, architecture decision, process used to train the model and get to final model and hyper-parameters.

My final model results were:
* training set accuracy of 94.9
* validation set accuracy of 94.6
* test set accuracy of 92.9


Architecture:

* LeNet achitecture was chosen. 
  
* Classification problem in LeNet is similar to Traffic Sign Classification. A small change in the LeNet  architecture can make it adapt to Traffic Sign classification.
  
* Training accuracy on training set, validation set and test set are very close. This indicates that model has tun well.

Fine tuning the model:

* Learning rate was achieved by using delta increase or decrease technique and was set to 0.0088, also while learning rate was changed everything else was kept constant.
* BATCH size was also chosen by binary method, and keeping other variables constant. It was found optimal at 65.
* EPOCHS was also chosen by binary method, while keeping other variables contant. It was finally set to 100.
* The training exit when training accuracy goes above 94% and model is saved at this moment.
* DROPOUTS helped achive better accuracy, it was also selected using binary method, while keeping other variables constant. Finally setting keep_prob to 0.68


### Test a Model on New Images

#### 1. Following are five German traffic signs found on the web. 

Here are five German traffic signs that I found on the web:

![Test Image German 1](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/five_german_signs/speed_60.png) ![Test Image German 2](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/five_german_signs/wild_animal.png) ![Test Image German 3](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/five_german_signs/speed_120.png) 
![Test Image German 4](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/five_german_signs/speed_100.png) ![Test Image German 5](https://github.com/agoswami/sdcnd/blob/master/Term1-P2-Traffic-Sign-Classifier-Project/five_german_signs/speed_30.png)

All first four images are difficult to classify because it is dark. Specially Speed Limit (120km/h) because it is hard to see it visually.

#### 2. Following are the predictions on five german traffic signs discussed above, and reason for one failure in prediction.

Here are the results of the prediction:

| Image			        |     Prediction	        					| 
|:---------------------:|:---------------------------------------------:| 
| Speed limit (60km/h)  		| Speed limit (60km/h)								| 
| Wild animals crossing   			| Wild animals crossing										|
| Speed limit (120km/h)				| Speed limit (100km/h)								|
| Speed limit (100km/h)     		| Speed limit (100km/h)				 				|
| Speed limit (30km/h)		| Speed limit (30km/h)      							|


The model was able to correctly guess 4 of the 5 traffic signs, which gives an accuracy of 80%. This compares favorably to the accuracy on the test set of 92.9%

#### 3. Following section will explain softmax probabilities on each image prediction. And, how the prediction chose a particular class.

The code for making predictions on my final model is located in the 9th cell of the Ipython notebook.

For the first image, the model is relatively sure that this is a Speed limit (60km/h) sign (probability of 1.0), and the image does contain a Speed limit (60km/h) sign. Same goes for the last image.

Below is a table of all the prediction and top 5 probabilities.

|       Traffic Sign   	|     	     Top 5  Probability			| Prediction |
|:---------------------:|:---------------------------------------------:| :---------------------------------------------:|
| Speed limit (60km/h) | 1.00000000e+00, 5.71865688e-12, 1.14227231e-13, 1.50066896e-14, 4.61580864e-16 | Speed limit (60km/h) | 
| Wild animals crossing  | 9.77782905e-01, 1.38095431e-02, 4.52117249e-03, 1.88645022e-03, 1.30264286e-03	| Wild animals crossing|
| Speed limit (120km/h)	 | 8.65320027e-01, 1.34679452e-01, 5.18626052e-07, 1.89818894e-09, 1.79749382e-10 | Speed limit (100km/h)|
| Speed limit (100km/h)  | 9.99999642e-01, 4.06174649e-07, 2.56612025e-20, 1.74703389e-20, 2.71637571e-21 | Speed limit (100km/h)|
| Speed limit (30km/h)	|	1.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00 | Speed limit (30km/h)|
